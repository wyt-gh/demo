//方便维护
const TABBAR_STATE = 'Tabbar_state'
const ADD_SHOPPING = 'add_shopping'


export {
  TABBAR_STATE,
  ADD_SHOPPING
}